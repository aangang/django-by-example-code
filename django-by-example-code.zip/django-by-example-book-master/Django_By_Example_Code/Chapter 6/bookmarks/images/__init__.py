default_app_config = 'images.apps.ImagesConfig'
